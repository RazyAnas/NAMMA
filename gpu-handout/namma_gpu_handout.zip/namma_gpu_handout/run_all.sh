#!/usr/bin/env bash
# Train every comparison run, optionally MODP, then score them. Safe to re-run: finished runs are skipped.
#   bash run_all.sh                 # full quality (30,000 steps per run)
#   STEPS=300 bash run_all.sh       # 2-minute smoke test first, if you like (then: rm -rf runs results)
#   SKIP_MODP=1 bash run_all.sh     # skip the MODP comparison
set -o pipefail
cd "$(dirname "$0")"
STEPS=${STEPS:-30000}; DOWNSCALE=${DOWNSCALE:-1}; MAX_POINTS=${MAX_POINTS:-0}; SKIP_MODP=${SKIP_MODP:-0}
eval "$(conda shell.bash hook 2>/dev/null)" 2>/dev/null && conda activate namma-gs 2>/dev/null || true
mkdir -p runs logs
# name | track | points | extra flags
RUNS="clean_sparse   clean    sparse  -
clean_random   clean    random  -
clean_boot     clean    boot    -
clean_gtdepth  clean    gtdepth -
degraded_sparse degraded sparse --appearance
degraded_boot  degraded boot    --appearance"
echo "$RUNS" | while read -r NAME TRACK PTS EXTRA; do
  [ "$EXTRA" = "-" ] && EXTRA=""
  if [ -f "runs/$NAME/run_info.json" ]; then echo "== $NAME already done, skipping"; continue; fi
  echo "== $NAME ($(date +%H:%M))"
  python scripts/train_gs.py --track "$TRACK" --points "data/$TRACK/points/$PTS.ply" --out "runs/$NAME" \
      --steps "$STEPS" --downscale "$DOWNSCALE" --max_points "$MAX_POINTS" $EXTRA 2>&1 | tee "logs/$NAME.log" | grep -E "step|Error|error" || true
  [ -f "runs/$NAME/run_info.json" ] || echo "!! $NAME FAILED: see logs/$NAME.log"
done
if [ "$SKIP_MODP" != "1" ]; then
  if conda env list 2>/dev/null | grep -q "^modp "; then
    for SRC in sparse boot_mv; do
      NAME=modp_clean_$SRC
      if [ -f "runs/$NAME/run_info.json" ]; then echo "== $NAME already done, skipping"; continue; fi
      echo "== $NAME ($(date +%H:%M))"
      conda activate namma-gs 2>/dev/null || true
      python scripts/make_modp_dataset.py clean $SRC "modp_data/clean_$SRC" "modp_data/clean_$SRC/config.yaml" > "logs/$NAME.log" 2>&1
      conda activate modp
      ( cd ext/Online-3DGS-Monocular && python ../../scripts/run_modp.py "../../modp_data/clean_$SRC/config.yaml" \
          "../../modp_data/clean_$SRC/test" "../../runs/$NAME" ) >> "logs/$NAME.log" 2>&1
      [ -f "runs/$NAME/run_info.json" ] || echo "!! $NAME FAILED: see logs/$NAME.log (fine to skip, see README)"
    done
    conda activate namma-gs 2>/dev/null || true
  else
    echo "== MODP environment not installed: skipping MODP (optional, see README step 4)"
  fi
fi
echo "== scoring"
python scripts/eval.py 2>&1 | tee logs/eval.log
echo "== done. Now run: bash pack_results.sh"
