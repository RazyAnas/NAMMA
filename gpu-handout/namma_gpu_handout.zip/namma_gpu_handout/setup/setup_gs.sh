#!/usr/bin/env bash
# Creates the conda environment "namma-gs" for our trainer (gsplat). Run from the handout folder: bash setup/setup_gs.sh
set -eo pipefail
command -v nvidia-smi >/dev/null || { echo "nvidia-smi not found: install the NVIDIA driver first (see README)"; exit 1; }
command -v conda >/dev/null || { echo "conda not found: install Miniconda first (see README)"; exit 1; }
CAP=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader | head -1); MAJOR=${CAP%%.*}
if [ "$MAJOR" -ge 10 ]; then   # RTX 50xx / Blackwell needs CUDA 12.8
  TORCH="torch==2.7.1 torchvision==0.22.1"; IDX=cu128; CUDA=12.8.1
else                           # RTX 20xx/30xx/40xx, A100, H100 ...
  TORCH="torch==2.5.1 torchvision==0.20.1"; IDX=cu124; CUDA=12.4.1
fi
echo "GPU compute capability $CAP -> PyTorch $IDX, CUDA toolkit $CUDA"
eval "$(conda shell.bash hook)"
conda create -y -n namma-gs -c conda-forge --override-channels python=3.10
conda activate namma-gs
# nvcc is needed once: gsplat compiles its CUDA kernels the first time it runs (5-10 minutes)
conda install -y -c "nvidia/label/cuda-$CUDA" -c conda-forge --override-channels cuda-toolkit
# point compilers at the conda CUDA headers/libs, saved in the environment so later runs see them too
conda env config vars set CUDA_HOME="$CONDA_PREFIX" CPATH="$CONDA_PREFIX/targets/x86_64-linux/include:$CONDA_PREFIX/include" LIBRARY_PATH="$CONDA_PREFIX/targets/x86_64-linux/lib:$CONDA_PREFIX/lib"
conda deactivate && conda activate namma-gs
pip install $TORCH --index-url https://download.pytorch.org/whl/$IDX
pip install "numpy<2" pillow ninja pyyaml pytorch-msssim==1.0.0 torchmetrics==1.4.1 lpips==0.1.4 gsplat==1.5.3
python scripts/check_env.py
