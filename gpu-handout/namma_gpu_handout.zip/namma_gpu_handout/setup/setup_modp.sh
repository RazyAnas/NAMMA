#!/usr/bin/env bash
# Optional: environment "modp" for Meta's MODP (facebookresearch/Online-3DGS-Monocular), the method we compare against.
# MODP only supports CUDA 11.8, so it needs a GPU older than RTX 50xx. Run from the handout folder: bash setup/setup_modp.sh
set -eo pipefail
CAP=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader | head -1); MAJOR=${CAP%%.*}
if [ "$MAJOR" -ge 10 ]; then echo "This GPU (compute capability $CAP) is too new for MODP's CUDA 11.8. Skip MODP: run_all.sh works without it."; exit 2; fi
mkdir -p ext
[ -d ext/Online-3DGS-Monocular ] || git clone https://github.com/facebookresearch/Online-3DGS-Monocular ext/Online-3DGS-Monocular
cd ext/Online-3DGS-Monocular && git checkout 7d75169074e4177e29284bc881a69f4866226ae1
eval "$(conda shell.bash hook)"
conda create -y -n modp -c conda-forge --override-channels python=3.9
conda activate modp
# CUDA 11.8 compiler plus a gcc it accepts (gcc 11) for the CUDA extensions MODP builds
conda install -y -c "nvidia/label/cuda-11.8.0" -c conda-forge --override-channels cuda-toolkit
conda install -y -c conda-forge --override-channels gxx_linux-64=11 gcc_linux-64=11
export CC=$(ls $CONDA_PREFIX/bin/x86_64-conda-linux-gnu-gcc) CXX=$(ls $CONDA_PREFIX/bin/x86_64-conda-linux-gnu-g++)
export CUDA_HOME=$CONDA_PREFIX
# point compilers at the conda CUDA headers/libs, saved in the environment so later runs see them too
conda env config vars set CUDA_HOME="$CONDA_PREFIX" CPATH="$CONDA_PREFIX/targets/x86_64-linux/include:$CONDA_PREFIX/include" LIBRARY_PATH="$CONDA_PREFIX/targets/x86_64-linux/lib:$CONDA_PREFIX/lib" CC="$CC" CXX="$CXX"
conda deactivate && conda activate modp
bash setup_env.sh                       # MODP's own installer (PyTorch 2.5.1 cu118, gsplat, DepthCov, lietorch)
python -c "import torch, lietorch, depth_cov; print('MODP env OK, CUDA', torch.cuda.is_available())"
