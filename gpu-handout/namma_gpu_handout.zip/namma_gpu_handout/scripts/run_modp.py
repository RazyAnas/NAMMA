"""Run MODP's online mapper on our frames/poses/points, then render the held-out test views.

Run from inside the MODP repository with its own environment:
  cd ext/Online-3DGS-Monocular && python ../../scripts/run_modp.py <config.yaml> <test folder> <run dir>
Mapping and MODP's own evaluation (on the views it saw) are MODP's code unchanged; the held-out renders use its renderer.
"""
import json, os, sys, time
sys.path.insert(0, os.getcwd())
import numpy as np
import torch
import torch.multiprocessing as mp
from PIL import Image

if __name__ == '__main__':
    cfg_path, test_dir, run_dir = [os.path.abspath(x) for x in sys.argv[1:4]]
    mp.set_start_method('spawn')
    from utils_new.tool_utils import load_config, mkdir_p
    from utils_new.scene_mapper import SceneMapper
    from utils_new.eval_utils import eval_gaussians
    from utils_new.dataset import load_dataset
    config = load_config(cfg_path)
    config['Results']['save_dir'] = f'{run_dir}/modp_logs'; mkdir_p(config['Results']['save_dir'])
    config['Mapper'].setdefault('scene_exposure_gain', 20.0)   # slam_new.py's default
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    mapper = SceneMapper(config)
    meta, infos = mapper.run()
    torch.cuda.synchronize(); map_s = time.time() - t0
    native = eval_gaussians(mapper.gaussians, infos, config)   # MODP's own numbers, on the frames it mapped
    tcfg = dict(config['Testset']); tcfg['dataset_path'] = test_dir; tcfg['scene_exposure_gain'] = config['Mapper']['scene_exposure_gain']
    test = load_dataset(tcfg, ret_original_dataset=True)
    mapper.gaussians.set_vignette_img(None)
    os.makedirs(f'{run_dir}/renders', exist_ok=True)
    t1 = time.time()
    with torch.no_grad():
        for i in range(len(test)):
            cam = test[i]; cam.to_device('cuda:0')
            img = mapper.gaussians.render(cam)['render'].clamp(0, 1)
            if img.shape[0] == 3: img = img.permute(1, 2, 0)
            frame = int(cam.name.split('.')[0].split('_')[-1])
            Image.fromarray((img.cpu().numpy() * 255).round().astype(np.uint8)).save(f'{run_dir}/renders/{frame:05d}.png')
    torch.cuda.synchronize(); fps = len(test) / (time.time() - t1)
    json.dump(native, open(f'{run_dir}/native_eval.json', 'w'), indent=1, default=str)
    info = dict(method='MODP', track=os.path.basename(os.path.dirname(cfg_path)), train_seconds=round(map_s, 1), render_fps=round(fps, 1),
                final_gaussians=int(meta['num_gaussians']), keyframes=int(meta['num_keyframes']), frames=int(meta['num_processed_frames']),
                peak_vram_gb=round(torch.cuda.max_memory_allocated() / 1e9, 2), gpu=torch.cuda.get_device_name(0), torch=torch.__version__)
    json.dump(info, open(f'{run_dir}/run_info.json', 'w'), indent=1)
    print(json.dumps(info))
