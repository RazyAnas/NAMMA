"""Score every finished run on the held-out test frames and write results/.

PSNR, SSIM and LPIPS (AlexNet, as MODP reports; VGG, as the 3DGS paper reports) against the clean test images.
"psnr_cc" also fits one colour transform per image first (fair for runs trained on footage with exposure changes).
python scripts/eval.py            # reads runs/*/renders, writes results/
"""
import csv, glob, json, os, shutil, sys
import numpy as np
import torch
from PIL import Image

DATA, RUNS, RES = 'data', 'runs', 'results'
EXAMPLES = [1240, 1528, 1832, 2120]  # fixed test frames shown in the side-by-side images
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
os.makedirs(RES, exist_ok=True)
cams = json.load(open(f'{DATA}/clean/cameras.json'))
gt_path = {c['frame']: f'{DATA}/{c["image"]}' for c in cams['test']}

from torchmetrics.image import StructuralSimilarityIndexMeasure
ssim_m = StructuralSimilarityIndexMeasure(data_range=1.0).to(dev)
lp = {}
for net in ['alex', 'vgg']:
    try:
        from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity
        lp[net] = LearnedPerceptualImagePatchSimilarity(net_type=net, normalize=True).to(dev)
    except Exception as e:  # weights are downloaded on first use; no internet = no LPIPS, other metrics still work
        print(f'LPIPS-{net} unavailable: {e}', file=sys.stderr)

def load(p, size=None):
    im = Image.open(p).convert('RGB')
    if size and im.size != size: im = im.resize(size, Image.BICUBIC)
    return torch.from_numpy(np.asarray(im).astype(np.float32) / 255.)

def psnr(x, y): return float(-10 * torch.log10(((x - y) ** 2).mean()))

def colour_match(x, y):  # least-squares affine colour map x -> y
    A = torch.cat([x.reshape(-1, 3), torch.ones(x[..., :1].numel(), 1, device=x.device)], 1)
    M = torch.linalg.lstsq(A, y.reshape(-1, 3)).solution
    return (A @ M).reshape(x.shape).clamp(0, 1)

summary = []
for rd in sorted(glob.glob(f'{RUNS}/*/')):
    name = os.path.basename(rd.rstrip('/')); out = f'{RES}/{name}'
    renders = sorted(glob.glob(f'{rd}/renders/*.png'))
    if not renders:
        print(f'skip {name}: no renders'); continue
    os.makedirs(f'{out}/examples', exist_ok=True)
    rows = []
    for rp in renders:
        f = int(os.path.basename(rp)[:5])
        if f not in gt_path: continue
        r = load(rp).to(dev); g = load(gt_path[f], (r.shape[1], r.shape[0])).to(dev)
        X, Y = r.permute(2, 0, 1)[None], g.permute(2, 0, 1)[None]
        row = dict(frame=f, psnr=psnr(r, g), psnr_cc=psnr(colour_match(r, g), g), ssim=float(ssim_m(X, Y)))
        with torch.no_grad():
            for net, m in lp.items(): row[f'lpips_{net}'] = float(m(X, Y))
        rows.append(row)
        if f in EXAMPLES: Image.fromarray((r.cpu().numpy() * 255).round().astype(np.uint8)).save(f'{out}/examples/{f:05d}.jpg', quality=95)
    keys = [k for k in rows[0] if k != 'frame']
    mean = {k: float(np.mean([r[k] for r in rows])) for k in keys}
    info = json.load(open(f'{rd}/run_info.json')) if os.path.exists(f'{rd}/run_info.json') else {}
    json.dump(dict(run=name, n_test=len(rows), n_expected=len(gt_path), mean=mean, info=info, per_frame=rows), open(f'{out}/metrics.json', 'w'), indent=1)
    for extra in ['run_info.json', 'train_log.csv', 'native_eval.json']:
        if os.path.exists(f'{rd}/{extra}'): shutil.copy(f'{rd}/{extra}', f'{out}/{extra}')
    summary.append(dict(run=name, n_test=len(rows), **{k: round(v, 4) for k, v in mean.items()},
                        train_min=round(info.get('train_seconds', float('nan')) / 60, 1) if info.get('train_seconds') else '',
                        gaussians=info.get('final_gaussians', ''), steps=info.get('steps', '')))
    print(f'{name:28s} PSNR {mean["psnr"]:.2f}  SSIM {mean["ssim"]:.3f}  LPIPS(alex) {mean.get("lpips_alex", float("nan")):.3f}  frames {len(rows)}/{len(gt_path)}')

if summary:
    cols = list(dict.fromkeys(k for s in summary for k in s))
    with open(f'{RES}/summary.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, cols); w.writeheader(); [w.writerow(s) for s in summary]
    # side-by-side: one row per example frame, ground truth first, then every run
    names = [s['run'] for s in summary]; tw, th = 320, 240
    sheet = Image.new('RGB', (tw * (len(names) + 1), th * len(EXAMPLES) + 24), 'white')
    from PIL import ImageDraw
    d = ImageDraw.Draw(sheet)
    for j, lab in enumerate(['ground truth'] + names): d.text((tw * j + 4, 4), lab, fill='black')
    for i, f in enumerate(EXAMPLES):
        if f not in gt_path: continue
        sheet.paste(Image.open(gt_path[f]).convert('RGB').resize((tw, th)), (0, 24 + th * i))
        for j, n in enumerate(names):
            p = f'{RES}/{n}/examples/{f:05d}.jpg'
            if os.path.exists(p): sheet.paste(Image.open(p).resize((tw, th)), (tw * (j + 1), 24 + th * i))
    sheet.save(f'{RES}/side_by_side.jpg', quality=92)
    print(f'wrote {RES}/summary.csv and {RES}/side_by_side.jpg')
