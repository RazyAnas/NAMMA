"""Write MODP (facebookresearch/Online-3DGS-Monocular) inputs from the handout data: same poses and points as our runs.

Layout MODP's "aria" loader reads: trajectory.json {"cameras": [{"image", "T_camera_world"}]}, rectified/<image>,
point_cloud/point_cloud_<frame>.npy (world xyz the tracker saw in that frame).
python scripts/make_modp_dataset.py <track> <point source> <out dir> <modp config out>
"""
import copy, json, os, shutil, sys
import numpy as np
track, src, out, cfg = sys.argv[1:5]
D = os.path.abspath('data'); out = os.path.abspath(out)
cams = json.load(open(f'{D}/{track}/cameras.json'))

def write(folder, entries, points):
    shutil.rmtree(folder, ignore_errors=True); os.makedirs(f'{folder}/rectified'); os.makedirs(f'{folder}/point_cloud')
    traj = []
    for c in entries:
        name = f'frame_{c["frame"]}.jpg'; shutil.copy(f'{D}/{c["image"]}', f'{folder}/rectified/{name}')
        traj.append({'image': name, 'T_camera_world': c['w2c']})
        P = points(c['frame']); np.save(f'{folder}/point_cloud/point_cloud_{c["frame"]}.npy', P.astype(np.float32))
    json.dump({'cameras': traj}, open(f'{folder}/trajectory.json', 'w'))

write(f'{out}/train', cams['train'], lambda f: np.load(f'{D}/{track}/modp_points/{src}/point_cloud_{f}.npy'))
# held-out views: rendered after mapping, never shown to MODP while it maps (one dummy point keeps the loader happy)
write(f'{out}/test', cams['test'], lambda f: np.zeros((1, 3)))
calib = dict(fx=cams['K'][0][0], fy=cams['K'][1][1], cx=cams['K'][0][2], cy=cams['K'][1][2], width=cams['width'], height=cams['height'], near=0.01, far=1000)
ds = dict(name=f'namma_{track}_{src}', type='aria', data_source='aria', dataset_path=f'{out}/train', num_threads=2,
          begin_cutoff=0, end_cutoff=0, vignette=False, use_vignette_type='post-render', Calibration=calib)
config = {
    'inherit_from': 'configs/aria/orb_tracking/aria_base.yaml',   # MODP's own settings from the paper, unchanged except below
    'Dataset': ds, 'Testset': copy.deepcopy(ds),
    # Poses are given and already accurate; turning MODP's pose refinement off keeps held-out views aligned.
    'Mapper': {'CameraOptimizer': {'use_camera_opt': False}},
}
import yaml
yaml.safe_dump(config, open(cfg, 'w'), sort_keys=False)
print(f'wrote {out} and {cfg}')
