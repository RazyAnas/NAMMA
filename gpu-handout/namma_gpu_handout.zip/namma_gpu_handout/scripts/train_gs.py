"""Train one 3D Gaussian Splatting model with gsplat and render the held-out test views.

Same poses, images and recipe for every run; only the starting points (--points) change.
python scripts/train_gs.py --track clean --points data/clean/points/boot.ply --out runs/clean_boot
"""
import argparse, json, math, os, time
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

p = argparse.ArgumentParser()
p.add_argument('--data', default='data')
p.add_argument('--track', default='clean', help='clean or degraded (training images and poses)')
p.add_argument('--points', required=True, help='initial point cloud (.ply with x y z red green blue)')
p.add_argument('--out', required=True)
p.add_argument('--steps', type=int, default=30000)
p.add_argument('--sh', type=int, default=3)
p.add_argument('--downscale', type=int, default=1, help='image downscale factor (1 = full 640x480)')
p.add_argument('--appearance', action='store_true', help='learn a per-training-image colour transform (for footage with exposure changes)')
p.add_argument('--max_points', type=int, default=0, help='randomly keep at most this many initial points (0 = all)')
p.add_argument('--backend', default='auto', help='gsplat (CUDA), torch (slow CPU reference, for tests) or auto')
p.add_argument('--seed', type=int, default=0)
a = p.parse_args()

torch.manual_seed(a.seed); np.random.seed(a.seed)
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
backend = a.backend if a.backend != 'auto' else ('gsplat' if dev == 'cuda' else 'torch')
os.makedirs(a.out, exist_ok=True)
cams = json.load(open(f'{a.data}/{a.track}/cameras.json'))
ds = a.downscale; Wd, H = cams['width'] // ds, cams['height'] // ds
K = torch.tensor(cams['K'], dtype=torch.float32); K[:2] /= ds

def load(path):
    im = Image.open(f'{a.data}/{path}').convert('RGB')
    if ds > 1: im = im.resize((Wd, H), Image.BICUBIC)
    return torch.from_numpy(np.asarray(im).astype(np.float32) / 255.)

train_imgs = torch.stack([load(c['image']) for c in cams['train']]).to(dev)                  # [T,H,W,3]
train_vm = torch.tensor([c['w2c'] for c in cams['train']], dtype=torch.float32, device=dev)  # world-to-camera
test_vm = torch.tensor([c['w2c'] for c in cams['test']], dtype=torch.float32, device=dev)
Kd = K.to(dev); T = len(train_imgs)

def read_ply(path):
    with open(path, 'rb') as fh:
        props, n, fmt = [], 0, 'ascii'
        while True:
            l = fh.readline().decode().strip()
            if l.startswith('format'): fmt = l.split()[1]
            if l.startswith('element vertex'): n = int(l.split()[-1])
            if l.startswith('property'): props.append((l.split()[1], l.split()[2]))
            if l == 'end_header': break
        if fmt == 'ascii':
            arr = np.loadtxt(fh, max_rows=n).reshape(n, -1); cols = {nm: arr[:, i] for i, (_, nm) in enumerate(props)}
        else:
            tm = {'float': '<f4', 'float32': '<f4', 'double': '<f8', 'uchar': 'u1', 'uint8': 'u1', 'int': '<i4'}
            arr = np.frombuffer(fh.read(), dtype=[(nm, tm[t]) for t, nm in props], count=n); cols = {nm: arr[nm] for _, nm in props}
    xyz = np.stack([cols['x'], cols['y'], cols['z']], 1).astype(np.float32)
    rgb = np.stack([cols['red'], cols['green'], cols['blue']], 1).astype(np.float32) / 255. if 'red' in cols else np.full_like(xyz, 0.5)
    return xyz, rgb

xyz, rgb = read_ply(a.points)
if a.max_points and len(xyz) > a.max_points:
    sel = np.random.default_rng(a.seed).choice(len(xyz), a.max_points, replace=False); xyz, rgb = xyz[sel], rgb[sel]
n0 = len(xyz)
pts = torch.from_numpy(xyz).to(dev)
# initial scale = mean distance to the 3 nearest neighbours (chunked, works on CPU too)
d2 = []
for i in range(0, len(pts), 4096):
    d2.append(torch.cdist(pts[i:i + 4096], pts).topk(4, largest=False).values[:, 1:])
dist = torch.cat(d2).clamp_min(1e-7).mean(1)
cam_centers = torch.linalg.inv(train_vm)[:, :3, 3]
scene_scale = float((cam_centers - cam_centers.mean(0)).norm(dim=1).max() * 1.1)
C0 = 0.28209479177387814
nsh = (a.sh + 1) ** 2
shs = torch.zeros(n0, nsh, 3, device=dev); shs[:, 0] = (torch.from_numpy(rgb).to(dev) - 0.5) / C0
params = torch.nn.ParameterDict({
    'means': torch.nn.Parameter(pts.clone()),
    'scales': torch.nn.Parameter(torch.log(dist)[:, None].repeat(1, 3)),
    'quats': torch.nn.Parameter(F.normalize(torch.rand(n0, 4, device=dev), dim=-1)),
    'opacities': torch.nn.Parameter(torch.logit(torch.full((n0,), 0.1, device=dev))),
    'sh0': torch.nn.Parameter(shs[:, :1].contiguous()),
    'shN': torch.nn.Parameter(shs[:, 1:].contiguous()),
})
lrs = {'means': 1.6e-4 * scene_scale, 'scales': 5e-3, 'quats': 1e-3, 'opacities': 5e-2, 'sh0': 2.5e-3, 'shN': 2.5e-3 / 20}
optimizers = {k: torch.optim.Adam([{'params': params[k], 'lr': lrs[k], 'name': k}], eps=1e-15) for k in params}
sched = torch.optim.lr_scheduler.ExponentialLR(optimizers['means'], gamma=0.01 ** (1.0 / a.steps))
if a.appearance:  # per-image 3x3 colour matrix + offset, gauge fixed by keeping their mean at identity
    app = torch.nn.Parameter(torch.cat([torch.eye(3), torch.zeros(3, 1)], 1)[None].repeat(T, 1, 1).to(dev))
    app_opt = torch.optim.Adam([app], lr=1e-3)

from gsplat.strategy import DefaultStrategy
long_run = a.steps >= 10000
strategy = DefaultStrategy(
    refine_start_iter=500 if long_run else max(1, a.steps // 10),
    refine_stop_iter=min(15000, a.steps // 2),
    refine_every=100 if long_run else max(10, a.steps // 10),
    reset_every=3000 if long_run else 10 ** 9,
    absgrad=False, verbose=False)
strategy.check_sanity(params, optimizers)
state = strategy.initialize_state(scene_scale=scene_scale)

def render_torch(means, quats, scales, opac, sh, vm, Kc, deg):
    """Dense reference rasteriser (every Gaussian against every pixel). CPU tests at tiny resolution only."""
    from gsplat.cuda._torch_impl import _quat_scale_to_covar_preci, _fully_fused_projection, _eval_sh_bases_fast
    covars, _ = _quat_scale_to_covar_preci(quats, scales, compute_preci=False)
    radii, m2d, depths, conics, _ = _fully_fused_projection(means, covars, vm[None], Kc[None], Wd, H)
    campos = torch.linalg.inv(vm)[:3, 3]
    dirs = F.normalize(means - campos, dim=-1); nb = (deg + 1) ** 2
    col = (_eval_sh_bases_fast(nb, dirs)[..., None] * sh[:, :nb]).sum(1) + 0.5
    col = col.clamp_min(0)
    vis = (radii[0] > 0).all(-1)
    idx = torch.nonzero(vis).squeeze(1); idx = idx[torch.argsort(depths[0, idx])]
    yy, xx = torch.meshgrid(torch.arange(H, device=dev) + 0.5, torch.arange(Wd, device=dev) + 0.5, indexing='ij')
    pix = torch.stack([xx, yy], -1).reshape(-1, 2)
    d = pix[None] - m2d[0, idx][:, None]                                     # [n,P,2]
    cn = conics[0, idx]
    sig = 0.5 * (cn[:, :1] * d[..., 0] ** 2 + cn[:, 2:] * d[..., 1] ** 2) + cn[:, 1:2] * d[..., 0] * d[..., 1]
    alpha = (opac[idx, None] * torch.exp(-sig)).clamp(max=0.999)
    alpha = torch.where((sig >= 0) & (alpha >= 1 / 255), alpha, torch.zeros_like(alpha))
    Tm = torch.cumprod(torch.cat([torch.ones_like(alpha[:1]), 1 - alpha[:-1]], 0), 0)
    img = ((alpha * Tm)[..., None] * col[idx, None]).sum(0).reshape(H, Wd, 3)
    return img, {'means2d': m2d, 'radii': radii, 'gaussian_ids': None, 'width': Wd, 'height': H, 'n_cameras': 1}

def render(vm, deg):
    means, quats = params['means'], params['quats']
    scales, opac = torch.exp(params['scales']), torch.sigmoid(params['opacities'])
    sh = torch.cat([params['sh0'], params['shN']], 1)
    if backend == 'gsplat':
        from gsplat import rasterization
        img, _, info = rasterization(means, quats, scales, opac, sh, vm[None], Kd[None], Wd, H, sh_degree=deg, packed=False)
        return img[0].clamp(0, 1) if not torch.is_grad_enabled() else img[0], info
    if not torch.is_grad_enabled(): return render_torch(means, quats, scales, opac, sh, vm, Kd, deg)[0].clamp(0, 1), None
    return render_torch(means, quats, scales, opac, sh, vm, Kd, deg)

from pytorch_msssim import ssim
sh_interval = max(1, a.steps // 30)
log = open(f'{a.out}/train_log.csv', 'w'); log.write('step,loss,l1,num_gaussians,seconds\n')
if dev == 'cuda': torch.cuda.reset_peak_memory_stats()
t0 = time.time()
for step in range(a.steps):
    i = np.random.randint(T); deg = min(a.sh, step // sh_interval)
    out, info = render(train_vm[i], deg)
    if a.appearance:
        out = out @ app[i, :, :3].T + app[i, :, 3]
    gt = train_imgs[i]
    l1 = (out - gt).abs().mean()
    loss = 0.8 * l1 + 0.2 * (1 - ssim(out.permute(2, 0, 1)[None], gt.permute(2, 0, 1)[None], data_range=1.0, size_average=True))
    if a.appearance:
        loss = loss + ((app.mean(0) - torch.cat([torch.eye(3), torch.zeros(3, 1)], 1).to(dev)) ** 2).sum()
    strategy.step_pre_backward(params, optimizers, state, step, info)
    loss.backward()
    for o in optimizers.values(): o.step(); o.zero_grad(set_to_none=True)
    if a.appearance: app_opt.step(); app_opt.zero_grad(set_to_none=True)
    sched.step()
    strategy.step_post_backward(params, optimizers, state, step, info, packed=False)
    if step % 100 == 0 or step == a.steps - 1:
        log.write(f'{step},{loss.item():.5f},{l1.item():.5f},{len(params["means"])},{time.time() - t0:.1f}\n'); log.flush()
    if step % 1000 == 0 or step == a.steps - 1:
        print(f'[{os.path.basename(a.out)}] step {step}/{a.steps} loss {loss.item():.4f} gaussians {len(params["means"])} {time.time() - t0:.0f}s', flush=True)
train_s = time.time() - t0

rd = f'{a.out}/renders'; os.makedirs(rd, exist_ok=True)
with torch.no_grad():
    t1 = time.time()
    for c, vm in zip(cams['test'], test_vm):
        img, _ = render(vm, a.sh)
        Image.fromarray((img.clamp(0, 1).cpu().numpy() * 255).round().astype(np.uint8)).save(f'{rd}/{c["frame"]:05d}.png')
    if dev == 'cuda': torch.cuda.synchronize()
    fps = len(cams['test']) / (time.time() - t1)
info = dict(track=a.track, points=os.path.basename(a.points), init_points=n0, steps=a.steps, downscale=ds, appearance=a.appearance,
            backend=backend, final_gaussians=len(params['means']), train_seconds=round(train_s, 1), render_fps=round(fps, 1),
            peak_vram_gb=round(torch.cuda.max_memory_allocated() / 1e9, 2) if dev == 'cuda' else None,
            gpu=torch.cuda.get_device_name(0) if dev == 'cuda' else 'cpu', torch=torch.__version__)
json.dump(info, open(f'{a.out}/run_info.json', 'w'), indent=1)
if os.environ.get('SAVE_PLY') == '1':  # optional: the trained splat, for viewing (not packed into results)
    from gsplat import export_splats
    export_splats(params['means'].detach(), params['scales'].detach(), F.normalize(params['quats'].detach(), dim=-1), params['opacities'].detach(),
                  params['sh0'].detach(), params['shN'].detach(), format='ply', save_to=f'{a.out}/splat.ply')
print(json.dumps(info))
