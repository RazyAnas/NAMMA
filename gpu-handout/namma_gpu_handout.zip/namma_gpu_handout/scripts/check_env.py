"""Quick health check: GPU visible, PyTorch has CUDA, gsplat compiles and renders, enough disk."""
import shutil, sys, time
ok = True
try:
    import torch
    print('PyTorch', torch.__version__, '| CUDA build', torch.version.cuda)
    if not torch.cuda.is_available():
        print('FAIL: PyTorch cannot see the GPU (see README troubleshooting: driver / wrong PyTorch build)'); sys.exit(1)
    p = torch.cuda.get_device_properties(0)
    print(f'GPU {p.name} | {p.total_memory / 1e9:.1f} GB | compute capability {p.major}.{p.minor}')
    if p.total_memory < 7.5e9: print('NOTE: under 8 GB VRAM. If a run runs out of memory, use: STEPS=30000 DOWNSCALE=2 bash run_all.sh')
except ImportError as e:
    print('FAIL:', e); sys.exit(1)
try:
    from gsplat import rasterization
    print('Compiling gsplat CUDA kernels if needed (first time only, 5-10 minutes)...', flush=True); t = time.time()
    n = 1000; d = 'cuda'
    means = torch.randn(n, 3, device=d) * 0.3 + torch.tensor([0, 0, 3.0], device=d)
    img, _, _ = rasterization(means, torch.nn.functional.normalize(torch.randn(n, 4, device=d), dim=-1), torch.full((n, 3), 0.02, device=d),
                              torch.full((n,), 0.8, device=d), torch.rand(n, 3, device=d), torch.eye(4, device=d)[None],
                              torch.tensor([[[300., 0, 160], [0, 300., 120], [0, 0, 1]]], device=d), 320, 240)
    print(f'gsplat OK (rendered a test image, mean {img.mean().item():.3f}, {time.time() - t:.0f}s)')
except Exception as e:
    ok = False; print('FAIL: gsplat could not compile or run:', repr(e)[:800])
for m in ['pytorch_msssim', 'torchmetrics', 'PIL']:
    try: __import__(m)
    except ImportError: ok = False; print('FAIL: missing python package', m)
free = shutil.disk_usage('.').free / 1e9
print(f'Free disk here: {free:.0f} GB' + ('  (need about 10 GB)' if free < 10 else ''))
print('ALL GOOD' if ok else 'SOMETHING IS WRONG: see the FAIL lines above and the README troubleshooting section')
sys.exit(0 if ok else 1)
