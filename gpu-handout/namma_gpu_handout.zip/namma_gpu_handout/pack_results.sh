#!/usr/bin/env bash
# Zip the scores, a few example images and short error logs into one small file to send back.
# Contains no personal data: home folder and user name are scrubbed from the logs.
set -uo pipefail
cd "$(dirname "$0")"
OUT="namma_results_$(date +%Y%m%d_%H%M).zip"
rm -rf _pack && mkdir -p _pack/results/logs
cp -r results/. _pack/results/ 2>/dev/null || echo "warning: no results/ folder (did run_all.sh finish?)"
for f in logs/*.log; do   # last 60 lines of each log, enough to diagnose a failure
  [ -f "$f" ] && tail -n 60 "$f" | sed -e "s#$HOME#~#g" -e "s#$(whoami)#user#g" > "_pack/results/logs/$(basename "$f")"
done
python - <<'PY' > _pack/results/environment.json 2>/dev/null || true
import json, platform, subprocess
info = {"os": platform.platform(), "python": platform.python_version()}
try:
    import torch; info.update(torch=torch.__version__, cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
except Exception as e: info["torch_error"] = str(e)
try: info["driver"] = subprocess.check_output(["nvidia-smi", "--query-gpu=driver_version,memory.total", "--format=csv,noheader"], text=True).strip()
except Exception: pass
print(json.dumps(info, indent=1))
PY
(cd _pack && zip -qr "../$OUT" results)
rm -rf _pack
echo "Send this file back: $PWD/$OUT ($(du -h "$OUT" | cut -f1))"
